﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class Update : Form
    {
        string username = "";
        public Update()
        {
            InitializeComponent();
        }
        public Update(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        private void Update_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();

        }

        private void buttonLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            SalesMan a = new SalesMan(username);
            a.Show();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string errors = "";


            errors += textBox2.Text.Length == 0 ? "\nPlease Provide Gmail" : "";
            errors += !textBox2.Text.Contains("@gmail.com") ? "\nPlease Provide A valid Gmail" : "";

            errors += (textBox1.Text.Length == 0 || textBox1.Text.Length != 11) ? "\nPlease Provide a Valid Mobile Number" : "";
            if (errors.Length != 0)
            {
                MessageBox.Show(errors, "Alert");
                return;
            }
            else
            {
                SqlConnection conn;
                SqlCommand cmd;
                SqlDataReader reader;
                string query;

                conn = new SqlConnection("Server=DESKTOP-PKH11PB;Database=csmss;User Id=hanif;Password=123456789;");
                int result = 0;
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    try
                    {
                        conn.Open();
                        query = "update Informations set Mobile='" + textBox1.Text + "',Gmail='" + textBox2.Text + "' where Username='" + username + "'";
                        cmd = new SqlCommand(query, conn);
                        result = cmd.ExecuteNonQuery();
                        conn.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Alert");
                        conn.Close();
                    }
                    if (result != 0)
                    {

                        MessageBox.Show("Successfully Updated", "Success");

                        this.Hide();
                        SalesMan a = new SalesMan(username);
                        a.Show();
                    }
                    else
                    {
                        MessageBox.Show("Something went wrong", "Error");
                    }
                }
                else
                {
                    MessageBox.Show("Fill up all the fields", "Error");
                }

            
        }
        }
    }
}
