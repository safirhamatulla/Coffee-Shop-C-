﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop
{
    public partial class Item_Information : Form
    {
        public Item_Information()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            uC_AddItem1.Visible = true;
            uC_AddItem1.BringToFront();
        }

        private void Item_Information_Load(object sender, EventArgs e)
        {
            uC_AddItem1.Visible = false;
            uC_UpdateItem1.Visible = false;
            uC_DeleteItem1.Visible = false;
            SqlConnection con = new SqlConnection("server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789");
            SqlCommand cmd = new SqlCommand("Select * from Menus", con);
            try
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataTable dt = new DataTable();
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            catch (Exception ec)
            {
                MessageBox.Show(ec.Message);
            }
        }

        private void uC_AddItem1_Load(object sender, EventArgs e)
        {

        }

        private void btnUpdateItem_Click(object sender, EventArgs e)
        {
            uC_UpdateItem1.Visible = true;
            uC_UpdateItem1.BringToFront();
        }

        private void btnRemoveItem_Click(object sender, EventArgs e)
        {
            uC_DeleteItem1.Visible = true;
            uC_DeleteItem1.BringToFront();
            

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
