﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop
{
    public partial class Profile_Owner : Form
    {
        
        public Profile_Owner()
        {
            InitializeComponent();
        }

      /*  private void btnEditProfile_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditOwnerProfile e1 = new EditOwnerProfile();
            e1.Show();
        }
      */
        private void Profile_Owner_Load(object sender, EventArgs e)
        {

            string connectionString= "server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789";
            SqlConnection con = new SqlConnection(connectionString);
            string query = "select * from Informations where Id='" + 2 + "'";
            SqlCommand sc = new SqlCommand(query, con);
            con.Open();
            using (SqlDataReader dr=sc.ExecuteReader())
            {
                if(dr.Read())
                {
                    lblOwnerName.Text = dr["Username"].ToString();
                    lblOwnerMobile.Text = dr["Mobile"].ToString();
                    lblOwnerEmail.Text = dr["Gmail"].ToString();
                    lblGender.Text = dr["Gender"].ToString();
                    lblDateofBird.Text = dr["DOB"].ToString();
                 //   lblname.Text = dr["name"].ToString();

                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            EditOwnerProfile e1 = new EditOwnerProfile();
            e1.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void lblOwnerAddress_Click(object sender, EventArgs e)
        {

        }
    }
}
