﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop
{
    public partial class AddSalesmanName : Form
    {
        public AddSalesmanName()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtSalesmanDob.Text = null;
            txtSalesmanEmail.Text = null;
            txtSalesmanMobile.Text = null;
            txtSalesmanName.Text = null;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string connectionString = "server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "insert into Informations SET name='" + txtSalesmanName.Text + "',Gmail='" + txtSalesmanEmail.Text + "',Mobile='" + txtSalesmanMobile.Text + "',DOB='" + txtSalesmanDob.Text +"',Gender='"+txtGender.Text+ "'";
                SqlDataReader da = cmd.ExecuteReader();
                MessageBox.Show("Update Succeed");

            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }


        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
