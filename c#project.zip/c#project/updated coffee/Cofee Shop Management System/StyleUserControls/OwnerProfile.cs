﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop.StyleUserControls
{
    public partial class OwnerProfile : UserControl
    {
        public OwnerProfile()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void OwnerProfile_Load(object sender, EventArgs e)
        {

        }

        private void btnProfile_Click(object sender, EventArgs e)
        {
          
            Profile_Owner p = new Profile_Owner();
            p.Show();
        }

        private void btnInformation_Click(object sender, EventArgs e)
        {
            Information i = new Information();
            i.Show();
        }
    }
}
