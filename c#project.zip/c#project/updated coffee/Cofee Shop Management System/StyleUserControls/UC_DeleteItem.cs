﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop.StyleUserControls
{
    public partial class UC_DeleteItem : UserControl
    {
        public UC_DeleteItem()
        {
            InitializeComponent();
        }

        private void UC_DeleteItem_Load(object sender, EventArgs e)
        {
            string stringConnection = "server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789";
            string query = "Select * from Menus";
            using (SqlConnection con = new SqlConnection(stringConnection))
            {
                con.Open();
                SqlDataAdapter sd = new SqlDataAdapter(query, con);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dataGridViewUpdateItem.DataSource = dt;
                


            }
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            if (txtItemSerial.Text.Length == 0) { MessageBox.Show("Provide the serial id", "Alert"); }
            else {
                int index = dataGridViewUpdateItem.CurrentCell.RowIndex;
                dataGridViewUpdateItem.Rows.RemoveAt(index);
                string connectionString = "server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "delete from Menus where Id='" + txtItemSerial.Text + "'";
                cmd.ExecuteNonQuery();
                con.Close();

                MessageBox.Show("Sucessfully Removed", "Sucess");
                txtItemSerial.Text = "";
            }
        }

    }
}
