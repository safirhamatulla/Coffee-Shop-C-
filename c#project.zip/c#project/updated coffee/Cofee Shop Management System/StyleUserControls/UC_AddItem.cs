﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop.StyleUserControls
{
    public partial class UC_AddItem : UserControl
    {
        string connectionString = "Server =DESKTOP-PKH11PB; Database = csmss; User Id = hanif; Password = 123456789; ";

        public UC_AddItem()
        {
            InitializeComponent();
        }

        private void guna2TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {

            //SqlCommand cmd;
            //string query;

            //SqlConnection conn = new SqlConnection("server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789");
            //conn.Open();
            // string query = "INSERT INTO Menus (menuName,menuCode,quantity,price,category) " +
            //"VALUES('" + txtitemName.Text + "','" + txtItemCode.Text + "','" + txtQuantity + "','" + txtCombo.Text +"')";
            //cmd = new SqlCommand(query, conn);

            //int result = cmd.ExecuteNonQuery();
            // conn.Close();
            SqlConnection conn;
            SqlCommand cmd;
            SqlDataReader reader;
            string query;

            conn = new SqlConnection(connectionString);
            int flag = 0;
            conn.Open();
            query ="select* from Menus where menuCode ='"+txtItemCode.Text +"'";
            cmd = new SqlCommand(query, conn);
            reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                flag = 1;
            }
            conn.Close();
            if (flag == 0)
            {
                int result = 0;



                conn.Open();
                query = "INSERT INTO Menus (menuName,menuCode,quantity,price,category) " +
                               "VALUES('" + txtitemName.Text + "','" + txtItemCode.Text + "','" + Int32.Parse(txtQuantity.Text) + "','" + Double.Parse(txtPrice.Text) + "','" + txtCombo.Text + "')";
                cmd = new SqlCommand(query, conn);

                result = cmd.ExecuteNonQuery();
                conn.Close();
                if (result != 0)
                {
                  MessageBox.Show("Successfully Added","Sucess");
                    this.Hide();
                    Item_Information a = new Item_Information();
                    a.Show();
                }
                else
                {
                    MessageBox.Show("Something went wrong","Error");
                    this.Hide();
                    Item_Information a = new Item_Information();
                    a.Show();


                }

            }
            else
            {
                MessageBox.Show("Menu code exists use another one","Alert");
                txtItemCode.Text ="";
            }




        }

        private void UC_AddItem_Load(object sender, EventArgs e)
        {

        }
    }
}


