﻿
namespace CoffeeShop.StyleUserControls
{
    partial class UC_DeleteItem
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridViewUpdateItem = new System.Windows.Forms.DataGridView();
            this.txtItemSerial = new Guna.UI2.WinForms.Guna2TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUpdateItem)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewUpdateItem
            // 
            this.dataGridViewUpdateItem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUpdateItem.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dataGridViewUpdateItem.Location = new System.Drawing.Point(36, 143);
            this.dataGridViewUpdateItem.Name = "dataGridViewUpdateItem";
            this.dataGridViewUpdateItem.Size = new System.Drawing.Size(516, 137);
            this.dataGridViewUpdateItem.TabIndex = 7;
            // 
            // txtItemSerial
            // 
            this.txtItemSerial.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtItemSerial.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtItemSerial.DefaultText = "";
            this.txtItemSerial.DisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(208)))), ((int)(((byte)(208)))), ((int)(((byte)(208)))));
            this.txtItemSerial.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(226)))), ((int)(((byte)(226)))), ((int)(((byte)(226)))));
            this.txtItemSerial.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtItemSerial.DisabledState.Parent = this.txtItemSerial;
            this.txtItemSerial.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(138)))), ((int)(((byte)(138)))), ((int)(((byte)(138)))));
            this.txtItemSerial.FillColor = System.Drawing.SystemColors.Control;
            this.txtItemSerial.FocusedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtItemSerial.FocusedState.Parent = this.txtItemSerial;
            this.txtItemSerial.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtItemSerial.HoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.txtItemSerial.HoverState.Parent = this.txtItemSerial;
            this.txtItemSerial.Location = new System.Drawing.Point(115, 100);
            this.txtItemSerial.Name = "txtItemSerial";
            this.txtItemSerial.PasswordChar = '\0';
            this.txtItemSerial.PlaceholderText = "";
            this.txtItemSerial.SelectedText = "";
            this.txtItemSerial.ShadowDecoration.Parent = this.txtItemSerial;
            this.txtItemSerial.Size = new System.Drawing.Size(200, 20);
            this.txtItemSerial.Style = Guna.UI2.WinForms.Enums.TextBoxStyle.Material;
            this.txtItemSerial.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Serial Number:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(209, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Delete Item";
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 18;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.FillColor = System.Drawing.SystemColors.AppWorkspace;
            this.guna2Button1.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button1.ForeColor = System.Drawing.Color.Black;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(192, 327);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.BorderRadius = 21;
            this.guna2Button1.ShadowDecoration.Color = System.Drawing.SystemColors.AppWorkspace;
            this.guna2Button1.ShadowDecoration.Enabled = true;
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(168, 38);
            this.guna2Button1.TabIndex = 13;
            this.guna2Button1.Text = "Remove";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            this.guna2Elipse1.TargetControl = this;
            // 
            // UC_DeleteItem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.guna2Button1);
            this.Controls.Add(this.dataGridViewUpdateItem);
            this.Controls.Add(this.txtItemSerial);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UC_DeleteItem";
            this.Size = new System.Drawing.Size(577, 426);
            this.Load += new System.EventHandler(this.UC_DeleteItem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUpdateItem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewUpdateItem;
        private Guna.UI2.WinForms.Guna2TextBox txtItemSerial;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
    }
}
