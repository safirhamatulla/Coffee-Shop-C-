﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class SalesMan : Form
    {
        string username = "";
        public SalesMan()
        {
            InitializeComponent();
        }
        public SalesMan(string uname)
        {
            InitializeComponent();
            username = uname;
            labelName.Text = uname;
        }
        private void buttonLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage a = new HomePage();
            a.Show();
        }

        private void SalesMan_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();

        }

        private void buttonDashboard_Click(object sender, EventArgs e)
        {
            this.Hide();
            SalesMan a = new SalesMan(username);
            a.Show();
           
        }

        private void buttonTakeOrder_Click(object sender, EventArgs e)
        {
            this.Hide();
            OwnerTakeOrder a = new OwnerTakeOrder(username);
            a.Show();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Update a = new Update(username);
            a.Show();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void labelBloodGroup_Click(object sender, EventArgs e)
        {

        }

        private void labelName_Click(object sender, EventArgs e)
        {

        }

        private void SalesMan_Load(object sender, EventArgs e)
        {
            if(username=="")
            {

            }
            else
            {
                SqlConnection conn;
                SqlCommand cmd;
                SqlDataReader reader;
                string query;
                string ut = "Salesman";
                string rs = "pending";
                string us = "Valid";
                conn = new SqlConnection("Server=DESKTOP-PKH11PB;Database=csmss;User Id=hanif;Password=123456789;");
                int result = 0;
                try
                {

                    conn.Open();
                    query = "select * from Informations where Username='"+username+"'";
                    cmd = new SqlCommand(query, conn);
                    reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {

                       label4.Text= reader.GetString(reader.GetOrdinal("Name"));
                        label8.Text = reader.GetString(reader.GetOrdinal("Username"));
                        label9.Text = reader.GetDateTime(reader.GetOrdinal("DOB")).ToString();
                        label11.Text = reader.GetString(reader.GetOrdinal("Gender"));
                        label13.Text = reader.GetString(reader.GetOrdinal("Gmail"));
                        label14.Text = reader.GetString(reader.GetOrdinal("Mobile"));





                    }
                    conn.Close();

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "Alert");
                    conn.Close();
                }
            }
        }
    }
}
