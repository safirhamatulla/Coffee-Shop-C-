﻿
namespace CoffeeShop
{
    partial class Item_Information
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnRemoveItem = new Guna.UI2.WinForms.Guna2Button();
            this.btnAddItem = new Guna.UI2.WinForms.Guna2Button();
            this.panelAdd = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.uC_AddItem1 = new CoffeeShop.StyleUserControls.UC_AddItem();
            this.uC_UpdateItem1 = new CoffeeShop.StyleUserControls.UC_UpdateItem();
            this.uC_DeleteItem1 = new CoffeeShop.StyleUserControls.UC_DeleteItem();
            this.panel1.SuspendLayout();
            this.panelAdd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.btnBack);
            this.panel1.Controls.Add(this.btnRemoveItem);
            this.panel1.Controls.Add(this.btnAddItem);
            this.panel1.Location = new System.Drawing.Point(17, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(207, 426);
            this.panel1.TabIndex = 1;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.btnBack.Location = new System.Drawing.Point(0, 3);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(80, 32);
            this.btnBack.TabIndex = 13;
            this.btnBack.Text = "<Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // btnRemoveItem
            // 
            this.btnRemoveItem.AutoRoundedCorners = true;
            this.btnRemoveItem.BackColor = System.Drawing.Color.Transparent;
            this.btnRemoveItem.BorderRadius = 18;
            this.btnRemoveItem.CheckedState.Parent = this.btnRemoveItem;
            this.btnRemoveItem.CustomImages.Parent = this.btnRemoveItem;
            this.btnRemoveItem.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnRemoveItem.Font = new System.Drawing.Font("Cooper Black", 11.25F);
            this.btnRemoveItem.ForeColor = System.Drawing.Color.Maroon;
            this.btnRemoveItem.HoverState.Parent = this.btnRemoveItem;
            this.btnRemoveItem.Location = new System.Drawing.Point(23, 225);
            this.btnRemoveItem.Name = "btnRemoveItem";
            this.btnRemoveItem.ShadowDecoration.BorderRadius = 21;
            this.btnRemoveItem.ShadowDecoration.Color = System.Drawing.Color.DodgerBlue;
            this.btnRemoveItem.ShadowDecoration.Enabled = true;
            this.btnRemoveItem.ShadowDecoration.Parent = this.btnRemoveItem;
            this.btnRemoveItem.Size = new System.Drawing.Size(168, 38);
            this.btnRemoveItem.TabIndex = 1;
            this.btnRemoveItem.Text = "Remove Item";
            this.btnRemoveItem.Click += new System.EventHandler(this.btnRemoveItem_Click);
            // 
            // btnAddItem
            // 
            this.btnAddItem.AutoRoundedCorners = true;
            this.btnAddItem.BackColor = System.Drawing.Color.Transparent;
            this.btnAddItem.BorderRadius = 18;
            this.btnAddItem.CheckedState.Parent = this.btnAddItem;
            this.btnAddItem.CustomImages.Parent = this.btnAddItem;
            this.btnAddItem.FillColor = System.Drawing.Color.DodgerBlue;
            this.btnAddItem.Font = new System.Drawing.Font("Cooper Black", 11.25F);
            this.btnAddItem.ForeColor = System.Drawing.Color.Maroon;
            this.btnAddItem.HoverState.Parent = this.btnAddItem;
            this.btnAddItem.Location = new System.Drawing.Point(23, 156);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.ShadowDecoration.BorderRadius = 21;
            this.btnAddItem.ShadowDecoration.Color = System.Drawing.Color.DodgerBlue;
            this.btnAddItem.ShadowDecoration.Enabled = true;
            this.btnAddItem.ShadowDecoration.Parent = this.btnAddItem;
            this.btnAddItem.Size = new System.Drawing.Size(168, 38);
            this.btnAddItem.TabIndex = 1;
            this.btnAddItem.Text = "Add Item";
            this.btnAddItem.Click += new System.EventHandler(this.btnAddItem_Click);
            // 
            // panelAdd
            // 
            this.panelAdd.Controls.Add(this.uC_DeleteItem1);
            this.panelAdd.Controls.Add(this.uC_UpdateItem1);
            this.panelAdd.Controls.Add(this.uC_AddItem1);
            this.panelAdd.Controls.Add(this.label1);
            this.panelAdd.Controls.Add(this.dataGridView1);
            this.panelAdd.Location = new System.Drawing.Point(230, 15);
            this.panelAdd.Name = "panelAdd";
            this.panelAdd.Size = new System.Drawing.Size(577, 426);
            this.panelAdd.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(236, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 34);
            this.label1.TabIndex = 5;
            this.label1.Text = "Items";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Enabled = false;
            this.dataGridView1.Location = new System.Drawing.Point(8, 82);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(550, 332);
            this.dataGridView1.TabIndex = 4;
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            this.guna2Elipse1.TargetControl = this.panelAdd;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.BorderRadius = 30;
            this.guna2Elipse2.TargetControl = this.panelAdd;
            // 
            // uC_AddItem1
            // 
            this.uC_AddItem1.BackColor = System.Drawing.SystemColors.Control;
            this.uC_AddItem1.Location = new System.Drawing.Point(8, -3);
            this.uC_AddItem1.Name = "uC_AddItem1";
            this.uC_AddItem1.Size = new System.Drawing.Size(560, 425);
            this.uC_AddItem1.TabIndex = 6;
            this.uC_AddItem1.Load += new System.EventHandler(this.uC_AddItem1_Load);
            // 
            // uC_UpdateItem1
            // 
            this.uC_UpdateItem1.BackColor = System.Drawing.SystemColors.Control;
            this.uC_UpdateItem1.Location = new System.Drawing.Point(8, 0);
            this.uC_UpdateItem1.Name = "uC_UpdateItem1";
            this.uC_UpdateItem1.Size = new System.Drawing.Size(577, 426);
            this.uC_UpdateItem1.TabIndex = 8;
            // 
            // uC_DeleteItem1
            // 
            this.uC_DeleteItem1.BackColor = System.Drawing.SystemColors.Control;
            this.uC_DeleteItem1.Location = new System.Drawing.Point(8, 0);
            this.uC_DeleteItem1.Name = "uC_DeleteItem1";
            this.uC_DeleteItem1.Size = new System.Drawing.Size(577, 426);
            this.uC_DeleteItem1.TabIndex = 9;
            // 
            // Item_Information
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(803, 548);
            this.Controls.Add(this.panelAdd);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Item_Information";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item_Information";
            this.Load += new System.EventHandler(this.Item_Information_Load);
            this.panel1.ResumeLayout(false);
            this.panelAdd.ResumeLayout(false);
            this.panelAdd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnRemoveItem;
        private Guna.UI2.WinForms.Guna2Button btnAddItem;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel panelAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private StyleUserControls.UC_AddItem uC_AddItem1;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private StyleUserControls.UC_DeleteItem uC_DeleteItem1;
        private StyleUserControls.UC_UpdateItem uC_UpdateItem1;
    }
}