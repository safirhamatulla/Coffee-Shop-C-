﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class Owner : Form
    {
        public Owner()
        {
            InitializeComponent();
        }

        private void btnSalesmanInformation_Click(object sender, EventArgs e)
        {
            Information i = new Information();
            i.Show();
        }

        private void ownerProfile1_Load(object sender, EventArgs e)
        {

        }

        private void Owner_Load(object sender, EventArgs e)
        {
           
        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            Item_Information i1 = new Item_Information();
            i1.Show();
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            OwnerTakeOrder ot = new OwnerTakeOrder();
            ot.Show();
        }

        private void guna2Button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage h1 = new HomePage();
            h1.Show();
        }

        private void Owner_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
