﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoffeeShop
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void dateTimePickerDob_ValueChanged(object sender, EventArgs e)
        {

        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBoxName_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButtonFemale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBoxEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxMobileNumber_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogIn a = new LogIn();
            a.Show();
        }

        private void Registration_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();

        }

        private void buttonResister_Click(object sender, EventArgs e)
        {
            string errors = "";
            errors += textBoxName.Text.Length == 0 ? "Please Provide Name" : "";
            errors += textBoxPassword.Text.Length == 0 ? "\nPlease Provide Password" : "";

            errors += textBoxUsername.Text.Length == 0 ? "\nPlease Provide User Name" : "";
            errors += textBoxEmail.Text.Length == 0 ? "\nPlease Provide Gmail" : "";
            errors += !textBoxEmail.Text.Contains("@gmail.com")  ? "\nPlease Provide A valid Gmail" : "";
            if (!radioButtonFemale.Checked && !radioButtonMale.Checked)
                errors += "\nPlease Provide Gender";
            errors += (textBoxMobileNumber.Text.Length == 0 || textBoxMobileNumber.Text.Length != 11) ? "\nPlease Provide a Valid Mobile Number" : "";

            if (errors.Length != 0)
            {
                MessageBox.Show(errors, "Filled the flowing!");
                return;
            }
            else
            {
                string gend = radioButtonFemale.Checked ? "Female" : "Male";
                SqlConnection conn;
                SqlCommand cmd;
                string query;
                string ut = "Salesman";
                string rs = "pending";
                string us = "Valid";
                conn = new SqlConnection("server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789");
                int result = 0;
                try
                {

                    conn.Open();             
                    query = "INSERT INTO Informations (Username,Gmail,DOB,Mobile,Gender,Name) " +
                                            "VALUES('" + textBoxUsername.Text + "','" + textBoxEmail.Text + "','" + dateTimePickerDob.Text + "','" + textBoxMobileNumber.Text +
                                            "','" + gend+ "','" + textBoxName.Text + "')";
                    cmd = new SqlCommand(query, conn);
                    
                    result = cmd.ExecuteNonQuery();
                    conn.Close();

                }
                catch (Exception)
                {
                    MessageBox.Show("User Name Already exists!", "Alert");
                    conn.Close();
                }
                if (result != 0)
                {
                    try
                    {

                        conn.Open();


                        query = "INSERT INTO Users (Username,Password,Usertype,RegistrationStatus,UserStatus) " +
                                                "VALUES('" + textBoxUsername.Text + "','" + textBoxPassword.Text + "','" + ut + "','" + rs + "','" + us + "')";
                        cmd = new SqlCommand(query, conn);

                        result = cmd.ExecuteNonQuery();
                        conn.Close();

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString(), "Alert");
                        conn.Close();
                    }

                    MessageBox.Show("Successfully registered", "Message");
                    this.Hide();
                    LogIn f1 = new LogIn();
                    f1.Show();

                }
                else

                {
                    MessageBox.Show("Somthing went wrong","Error");
                }


            }

        }
    }
}
