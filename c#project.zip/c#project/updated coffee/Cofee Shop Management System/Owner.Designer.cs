﻿
namespace CoffeeShop
{
    partial class Owner
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnItems = new Guna.UI2.WinForms.Guna2Button();
            this.btnPlaceOrder = new Guna.UI2.WinForms.Guna2Button();
            this.btnSalesmanInformation = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ownerProfile1 = new CoffeeShop.StyleUserControls.OwnerProfile();
            this.guna2Elipse1 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.guna2Elipse2 = new Guna.UI2.WinForms.Guna2Elipse(this.components);
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.guna2Button1);
            this.panel1.Controls.Add(this.btnItems);
            this.panel1.Controls.Add(this.btnPlaceOrder);
            this.panel1.Controls.Add(this.btnSalesmanInformation);
            this.panel1.Location = new System.Drawing.Point(12, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(235, 426);
            this.panel1.TabIndex = 0;
            // 
            // guna2Button1
            // 
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BackColor = System.Drawing.Color.Transparent;
            this.guna2Button1.BorderRadius = 18;
            this.guna2Button1.CheckedState.Parent = this.guna2Button1;
            this.guna2Button1.CustomImages.Parent = this.guna2Button1;
            this.guna2Button1.Font = new System.Drawing.Font("Cooper Black", 11.25F);
            this.guna2Button1.ForeColor = System.Drawing.Color.Maroon;
            this.guna2Button1.HoverState.Parent = this.guna2Button1;
            this.guna2Button1.Location = new System.Drawing.Point(41, 362);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.ShadowDecoration.BorderRadius = 21;
            this.guna2Button1.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.guna2Button1.ShadowDecoration.Enabled = true;
            this.guna2Button1.ShadowDecoration.Parent = this.guna2Button1;
            this.guna2Button1.Size = new System.Drawing.Size(168, 38);
            this.guna2Button1.TabIndex = 3;
            this.guna2Button1.Text = "Log Out";
            this.guna2Button1.Click += new System.EventHandler(this.guna2Button1_Click);
            // 
            // btnItems
            // 
            this.btnItems.AutoRoundedCorners = true;
            this.btnItems.BackColor = System.Drawing.Color.Transparent;
            this.btnItems.BorderRadius = 18;
            this.btnItems.CheckedState.Parent = this.btnItems;
            this.btnItems.CustomImages.Parent = this.btnItems;
            this.btnItems.Font = new System.Drawing.Font("Cooper Black", 11.25F);
            this.btnItems.ForeColor = System.Drawing.Color.Maroon;
            this.btnItems.HoverState.Parent = this.btnItems;
            this.btnItems.Location = new System.Drawing.Point(41, 163);
            this.btnItems.Name = "btnItems";
            this.btnItems.ShadowDecoration.BorderRadius = 21;
            this.btnItems.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnItems.ShadowDecoration.Enabled = true;
            this.btnItems.ShadowDecoration.Parent = this.btnItems;
            this.btnItems.Size = new System.Drawing.Size(168, 38);
            this.btnItems.TabIndex = 2;
            this.btnItems.Text = "Items";
            this.btnItems.Click += new System.EventHandler(this.btnItems_Click);
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.AutoRoundedCorners = true;
            this.btnPlaceOrder.BackColor = System.Drawing.Color.Transparent;
            this.btnPlaceOrder.BorderRadius = 18;
            this.btnPlaceOrder.CheckedState.Parent = this.btnPlaceOrder;
            this.btnPlaceOrder.CustomImages.Parent = this.btnPlaceOrder;
            this.btnPlaceOrder.Font = new System.Drawing.Font("Cooper Black", 11.25F);
            this.btnPlaceOrder.ForeColor = System.Drawing.Color.Maroon;
            this.btnPlaceOrder.HoverState.Parent = this.btnPlaceOrder;
            this.btnPlaceOrder.Location = new System.Drawing.Point(41, 26);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.ShadowDecoration.BorderRadius = 21;
            this.btnPlaceOrder.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnPlaceOrder.ShadowDecoration.Enabled = true;
            this.btnPlaceOrder.ShadowDecoration.Parent = this.btnPlaceOrder;
            this.btnPlaceOrder.Size = new System.Drawing.Size(168, 38);
            this.btnPlaceOrder.TabIndex = 1;
            this.btnPlaceOrder.Text = "Take Order";
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // btnSalesmanInformation
            // 
            this.btnSalesmanInformation.AutoRoundedCorners = true;
            this.btnSalesmanInformation.BackColor = System.Drawing.Color.Transparent;
            this.btnSalesmanInformation.BorderRadius = 18;
            this.btnSalesmanInformation.CheckedState.Parent = this.btnSalesmanInformation;
            this.btnSalesmanInformation.CustomImages.Parent = this.btnSalesmanInformation;
            this.btnSalesmanInformation.Font = new System.Drawing.Font("Cooper Black", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalesmanInformation.ForeColor = System.Drawing.Color.Maroon;
            this.btnSalesmanInformation.HoverState.Parent = this.btnSalesmanInformation;
            this.btnSalesmanInformation.Location = new System.Drawing.Point(36, 237);
            this.btnSalesmanInformation.Name = "btnSalesmanInformation";
            this.btnSalesmanInformation.ShadowDecoration.BorderRadius = 21;
            this.btnSalesmanInformation.ShadowDecoration.Color = System.Drawing.Color.FromArgb(((int)(((byte)(94)))), ((int)(((byte)(148)))), ((int)(((byte)(255)))));
            this.btnSalesmanInformation.ShadowDecoration.Enabled = true;
            this.btnSalesmanInformation.ShadowDecoration.Parent = this.btnSalesmanInformation;
            this.btnSalesmanInformation.Size = new System.Drawing.Size(173, 38);
            this.btnSalesmanInformation.TabIndex = 0;
            this.btnSalesmanInformation.Text = "Salesman Information";
            this.btnSalesmanInformation.Click += new System.EventHandler(this.btnSalesmanInformation_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.HighlightText;
            this.panel2.Controls.Add(this.ownerProfile1);
            this.panel2.ForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(241, 10);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(546, 426);
            this.panel2.TabIndex = 1;
            // 
            // ownerProfile1
            // 
            this.ownerProfile1.Location = new System.Drawing.Point(4, 0);
            this.ownerProfile1.Name = "ownerProfile1";
            this.ownerProfile1.Size = new System.Drawing.Size(546, 426);
            this.ownerProfile1.TabIndex = 0;
            this.ownerProfile1.Load += new System.EventHandler(this.ownerProfile1_Load);
            // 
            // guna2Elipse1
            // 
            this.guna2Elipse1.BorderRadius = 30;
            this.guna2Elipse1.TargetControl = this.panel2;
            // 
            // guna2Elipse2
            // 
            this.guna2Elipse2.TargetControl = this.ownerProfile1;
            // 
            // Owner
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(803, 548);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Owner";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Owner";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Owner_FormClosing);
            this.Load += new System.EventHandler(this.Owner_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Guna.UI2.WinForms.Guna2Button btnSalesmanInformation;
        private System.Windows.Forms.Panel panel2;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse1;
        private StyleUserControls.OwnerProfile ownerProfile1;
        private Guna.UI2.WinForms.Guna2Button btnPlaceOrder;
        private Guna.UI2.WinForms.Guna2Button btnItems;
        private Guna.UI2.WinForms.Guna2Elipse guna2Elipse2;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
    }
}