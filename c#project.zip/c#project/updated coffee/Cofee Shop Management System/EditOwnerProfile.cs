﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace CoffeeShop
{
    public partial class EditOwnerProfile : Form
    {
        string connectionString = "server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789";

        public static string name;
        public static string email;
        public static string mobileNumber;
        public static string address;
        public EditOwnerProfile()
        {
            InitializeComponent();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            
            txtOwnerEmail.Text = null;
            txtOwnerMobile.Text = null;
         
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string errors = "";


            errors += txtOwnerEmail.Text.Length == 0 ? "\nPlease Provide Gmail" : "";
            errors += !txtOwnerEmail.Text.Contains("@gmail.com") ? "\nPlease Provide A valid Gmail" : "";

            errors += (txtOwnerMobile.Text.Length == 0 || txtOwnerMobile.Text.Length != 11) ? "\nPlease Provide a Valid Mobile Number" : "";
            if (errors.Length != 0)
            {
                MessageBox.Show(errors, "Alert");
                return;
            }
            else {
                string un = "admin";
                SqlConnection con = new SqlConnection(connectionString);
                con.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = con;
                cmd.CommandText = "Update Informations SET Gmail='" + txtOwnerEmail.Text + "',Mobile='" + txtOwnerMobile.Text + "' where Username='" + un + "'";
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("Update Succeed");
                this.Hide();

            }
            
        }

        private void EditOwnerProfile_Load(object sender, EventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();

        }

        private void EditOwnerProfile_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
