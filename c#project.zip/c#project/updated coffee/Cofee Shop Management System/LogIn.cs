﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn;
            SqlCommand cmd;
            SqlDataReader reader;
            string query;
            string ut="", rs="", us="",uname="";

            conn = new SqlConnection("server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789");
            int flag=0;
            try
            {
                conn.Open();
                query = "SELECT * FROM Users WHERE Username='" + textBoxId.Text + "' and Password='" + textBoxPass.Text + "'";
                cmd = new SqlCommand(query, conn);
                 reader = cmd.ExecuteReader();
                while (reader.Read())
                {

                    flag = 1;

                     uname= reader.GetString(reader.GetOrdinal("Username"));
                    ut = reader.GetString(reader.GetOrdinal("Usertype"));
                    rs = reader.GetString(reader.GetOrdinal("RegistrationStatus"));
                    us = reader.GetString(reader.GetOrdinal("UserStatus"));






                }
                conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Alert");
                conn.Close();
            }
            if(flag==0)
            {
                MessageBox.Show("Invalid Username or Password", "Alert");
            }
            else
            {
                if(ut=="Owner")
                {
                    this.Hide();
                    Owner a = new Owner();
                    a.Show();

                }
                else if(ut=="Salesman")
                {
                    if(rs=="approved")//if(rs=="approved"||rs=="pending")
                    {
                        if(us=="Valid")
                        {
                            this.Hide();
                            SalesMan b= new SalesMan(uname);
                            b.Show();
                        }
                        else
                        {
                            MessageBox.Show("You are restricted by the owner. Contact with Owner", "Invalid");

                        }

                    }
                    else
                    {
                        MessageBox.Show("You are not approved yet. Contact with Owner", "Pending");
                    }

                }

            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void linkLabelNewAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Registration a = new Registration();
            a.Show();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBoxPass_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBoxUser_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            HomePage a = new HomePage();
            a.Show();  
        }

        private void LogIn_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.textBoxId.Text = "";
            this.textBoxPass.Clear();
        }
    }
}
