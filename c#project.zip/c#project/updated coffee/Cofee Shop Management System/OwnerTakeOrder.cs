﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace CoffeeShop
{
    public partial class OwnerTakeOrder : Form
    {
        string username = "";
        string connectionString = "server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789";
        //conn = new SqlConnection("Server=DESKTOP-PKH11PB;Database=csmss;User Id=hanif;Password=123456789;");
        public OwnerTakeOrder()
        {
            InitializeComponent();
        }
        public OwnerTakeOrder(string username)
        {
            InitializeComponent();
            this.username = username;
        }
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void OwnerTakeOrder_Load(object sender, EventArgs e)
        {
            using (SqlConnection sqlCon = new SqlConnection(connectionString))
            {
                sqlCon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("select * from Menus", sqlCon);
                DataTable dtbl = new DataTable();
                sqlDa.Fill(dtbl);
                dgvOrderMenu.DataSource = dtbl;
            }


        }

        private void comboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dgvOrderMenu_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {


        }

        private void txtitemName_TextChanged(object sender, EventArgs e)
        {




        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            
        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuantuty_ValueChanged(object sender, EventArgs e)
        {
            double x = Double.Parse(txtQuantity.Value.ToString());
            double y = Double.Parse(txtItemPrice.Text);
            txtItemTotalPrice.Text = (x * y).ToString();
        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            txtitemName.Text = "";
     
       
            txtQuantity.Value = 0;
            txtItemTotalPrice.Text = "";
            string errors = "";
            errors += txtId.Text.Length == 0 ? "Please Provide Id" : "";
            if (errors.Length != 0)
            {
                MessageBox.Show(errors, "Alert");
                return;
            }
            else
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = "select * from Menus where Id= " + int.Parse(txtId.Text);
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader dr = cmd.ExecuteReader();
                int flag = 0;
                if (dr.Read())
                {
                    flag = 1;
                    txtitemName.Text = (dr["menuName"].ToString());
                    txtItemPrice.Text = (dr["price"].ToString());

                    double x = Double.Parse(txtItemPrice.Text);
                    double y = Double.Parse(txtQuantity.Value.ToString());
                    txtItemTotalPrice.Text = (x * y).ToString();
                    
                }
                connection.Close();

                if (flag == 0)
                {
                    MessageBox.Show("No data found", "Alert");
                }
            }
            

        }

        private void btnBack_Click_1(object sender, EventArgs e)
        {
            if (username == "")
            {
                this.Hide();
                Owner a = new Owner();
                a.Show();

            }
            else
            {
                this.Hide();
                SalesMan a = new SalesMan(username);
                a.Show();

            }
        }

        private void btnAddToCart_Click_1(object sender, EventArgs e)
        {
            
            string errors = "";
            errors += txtitemName.Text.Length == 0 ? "Please Provide ItemName" : "";
            errors += txtQuantity.Value <= 0 ? "\nQuntity Can not be 0 or negetive" : "";
            if (errors.Length != 0)
            {
                MessageBox.Show(errors, "Filled the flowing!");
                return;
            }
            else
            {
                addData(txtitemName.Text, txtItemPrice.Text, txtQuantity.Value.ToString(), txtItemTotalPrice.Text);
                txtitemName.Text = "";
                txtQuantity.Value = 0;
                txtItemTotalPrice.Text = "";
            }
        }
        private void addData(string name, string price, string quantity, string totalPrice)
        {
            string[] rows = { name, price, quantity, totalPrice };
            dgvBill.Rows.Add(rows);
        }

        private void dgvBill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a = Double.Parse(guna2TextBox1.Text);
            double b =Double.Parse( guna2NumericUpDown1.Value.ToString());
            double c = a - a * (b / 100);

            if (dgvBill.Rows.Count > 1)

            {
                SaveFileDialog sfd = new SaveFileDialog();

              sfd.Filter = "PDF (*.pdf)|*.pdf";


                sfd.FileName = "Output.pdf";


                bool fileError = false;


                if (sfd.ShowDialog() == DialogResult.OK)


                {


                    if (File.Exists(sfd.FileName))


                    {


                        try


                        {


                            File.Delete(sfd.FileName);


                        }


                        catch (IOException ex)


                        {


                            fileError = true;


                            MessageBox.Show("It wasn't possible to write the data to the disk." + ex.Message);


                        }


                    }


                    if (!fileError)


                    {


                        try


                        {


                            PdfPTable pdfTable = new PdfPTable(dgvBill.Columns.Count);


                            pdfTable.DefaultCell.Padding = 3;


                            pdfTable.WidthPercentage = 100;


                            pdfTable.HorizontalAlignment = Element.ALIGN_LEFT;

                            foreach (DataGridViewColumn column in dgvBill.Columns)


                            {


                                PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));


                                pdfTable.AddCell(cell);


                            }

                            foreach (DataGridViewRow row in dgvBill.Rows)


                            {


                                foreach (DataGridViewCell cell in row.Cells)


                                {
                                    if (cell.Value!= null)
                                    {

                                        pdfTable.AddCell(cell.Value.ToString());
                                    }


                                }


                            }

                            using (FileStream stream = new FileStream(sfd.FileName, FileMode.Create))


                            {


                                Document pdfDoc = new Document(PageSize.A4, 10f, 20f, 20f, 10f);


                                PdfWriter.GetInstance(pdfDoc, stream);


                                pdfDoc.Open();
                                string un = username == "" ? "admin" : username;





                                Paragraph p = new Paragraph(" Cart Details:  " +
                                    "\n -----------------------------------------------------------" +
                                    "\n -----------------------------------------------------------" +


                                    "\n" +


                                    "\n Total - " + a +" BDT"+
                                     "\n (-) Discount(%) - " + b + "%" +
                                     "\n -----------------------------------------------------------" +
                                      "\n Adjusted Amount - " + c+ " BDT" +

                                      "\n -----------------------------------------------------------" +
                                      "\n (Rounding) Total Amount - " + Math.Round(c) + " BDT" +
                                      "\n -----------------------------------------------------------" +
                                      "\n Printed by - " + un +
                                          "\n Printed on - " + DateTime.Now +
                                       "\n -----------------------------------------------------------" +
                                        "\n -----------------------------------------------------------" +

                                        "\n"+
                                    "\n");


                                pdfDoc.Add(p);


                                pdfDoc.Add(pdfTable);


                                pdfDoc.Close();


                                stream.Close();


                            }

                            MessageBox.Show("Data Exported Successfully !!!", "Info");


                        }

                        catch (Exception ex)

                        {

                            MessageBox.Show("Error :" + ex.Message);

                        }


                    }


                }


            }


            else


            {


                MessageBox.Show("No Record To Export !!!", "Info");


            }




        }

        private void dgvOrderMenu_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int index = dgvBill.CurrentCell.RowIndex;
            if (index == 0||index==null)
            {
                MessageBox.Show("Nothing to Remove", "Alert");
            }
            else { dgvBill.Rows.RemoveAt(index); }
        }

        private void dgvBill_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            if ( dgvBill.Rows.Count > 1)
            {
                int sum = 0;
                for (int i = 0; i < dgvBill.Rows.Count; ++i)
                {
                    sum += Convert.ToInt32(dgvBill.Rows[i].Cells[3].Value);
                }
                guna2TextBox1.Text = sum.ToString();
            }
            else
            {
                guna2TextBox1.Text = "0";
            }
        }
    }
}
