﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CoffeeShop
{
    public partial class Information : Form
    {
        public Information()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddSalesmanName aN = new AddSalesmanName();
            aN.Show();
        }

        private void Information_Load(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection ("server =DESKTOP-PKH11PB; Initial Catalog = csmss; User ID = hanif; Password = 123456789"))
            {
                con.Open();
                string qur = "select * from Informations";
                SqlDataAdapter sd = new SqlDataAdapter(qur, con);
                DataTable dt = new DataTable();
                sd.Fill(dt);
                dgvShowSalesman.DataSource = dt;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            int index = dgvShowSalesman.CurrentCell.RowIndex;
            dgvShowSalesman.Rows.RemoveAt(index);
        }
    }
}
